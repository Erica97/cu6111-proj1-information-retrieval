alpha = 0
beta = 0.9
gamma = 0.1
